/* Statistics - Decompiled by JODE
 * Visit http://jode.sourceforge.net/
 */

class Statistics extends Feature
{
    public Statistics() {
	feature_.put("MEAN", new Integer(0));
    }
}
